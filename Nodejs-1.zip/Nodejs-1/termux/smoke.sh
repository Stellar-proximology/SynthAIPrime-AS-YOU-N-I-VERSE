#!/data/data/com.termux/files/usr/bin/bash
set -e

BASE_URL="http://localhost:3000"
API_KEY="dev-local-key"

echo "🚀 Starting Synthia Light smoke tests on Termux..."

# Wait for server to be ready
echo "⏳ Waiting for server to be ready..."
for i in {1..30}; do
    if curl -f -s "${BASE_URL}/healthz" > /dev/null 2>&1; then
        echo "✅ Server is ready!"
        break
    fi
    echo "   Attempt $i/30: Server not ready yet..."
    sleep 2
done

# Test health endpoints
echo "✅ Testing health endpoints..."
curl -f -s "${BASE_URL}/healthz" | jq .
curl -f -s "${BASE_URL}/readyz" | jq .

# 1) Create profile
echo "✅ Testing profile creation..."
curl -f -sX POST "${BASE_URL}/mods/profiles" \
  -H 'Content-Type: application/json' \
  -d '{"handle":"termux","email":"termux@synthia.local","birth":{"dateISO":"1990-09-18","time":"21:34","tz":"America/Los_Angeles","lat":37.7749,"lon":-122.4194}}' | jq .

# 2) Charts (trinity)
echo "✅ Testing chart generation..."
curl -f -sX POST "${BASE_URL}/mods/charts/natal" \
  -H 'Content-Type: application/json' \
  -d '{"profileHandle":"termux"}' | jq .

# 3) Resonance sentence (Body)
echo "✅ Testing resonance sentence..."
curl -f -sX POST "${BASE_URL}/mods/resonance/sentence" \
  -H 'Content-Type: application/json' \
  -d '{"profileHandle":"termux","system":"body"}' | jq .

# 4) Journal entry (auth required)
echo "✅ Testing journal entry creation..."
curl -f -sX POST "${BASE_URL}/mods/journal/entries" \
  -H "Authorization: Bearer ${API_KEY}" \
  -H 'Content-Type: application/json' \
  -d '{"profileHandle":"termux","text":"Termux reflection","tags":["mobile"]}' | jq .

# 5) Notebook (.ipynb)
echo "✅ Testing notebook generation..."
curl -f -s "${BASE_URL}/mods/journal/notebook?profile=termux" > journal.ipynb
echo "📔 Notebook saved as journal.ipynb"

# 6) Compile a tiny Kaboom game
echo "✅ Testing game compilation..."
GAME_RESULT=$(curl -f -sX POST "${BASE_URL}/mods/games-lite/compile" \
  -H 'Content-Type: application/json' \
  -d '{"spec":{"name":"termux-game","scenes":[{"name":"Boot","start":true}],"entities":[{"name":"Player","components":["pos"]}],"inputs":["space"],"goals":[{"id":"g1","description":"Test goal"}]}}')

echo "$GAME_RESULT" | jq .
PROJECT_ID=$(echo "$GAME_RESULT" | jq -r '.projectId')

# 7) Export zip (auth required)
echo "✅ Testing project export..."
curl -f -sX POST "${BASE_URL}/mods/builder/export" \
  -H "Authorization: Bearer ${API_KEY}" \
  -H 'Content-Type: application/json' \
  -d "{\"projectId\":\"${PROJECT_ID}\"}" | jq .

# 8) Download zip
echo "✅ Testing zip download..."
curl -f -s "${BASE_URL}/mods/bundler/download/${PROJECT_ID}" \
  -H "Authorization: Bearer ${API_KEY}" \
  -o "dist_${PROJECT_ID}.zip"

echo "📦 Mock zip saved as dist_${PROJECT_ID}.zip"

echo ""
echo "🎉 All Termux smoke tests passed!"
echo "📁 Generated files:"
echo "   - journal.ipynb"
echo "   - dist_${PROJECT_ID}.zip"
echo ""
echo "Termux setup verified and working correctly!"