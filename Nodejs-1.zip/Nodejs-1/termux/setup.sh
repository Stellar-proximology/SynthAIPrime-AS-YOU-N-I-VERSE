#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "🚀 Setting up Synthia Light on Termux..."

# Update packages
echo "📦 Updating Termux packages..."
pkg update -y
pkg upgrade -y

# Install required packages
echo "📦 Installing Node.js and SQLite..."
pkg install -y nodejs sqlite zip unzip curl jq

# Verify installations
echo "✅ Verifying installations..."
node --version
npm --version
sqlite3 --version

# Clone or download project (assuming it's already present)
if [ ! -d "synthia-light" ]; then
    echo "📁 Please place the Synthia Light project in ~/synthia-light"
    echo "Current directory: $(pwd)"
    echo "Create project directory and copy files, then run this script again."
    exit 1
fi

cd synthia-light

# Install dependencies
echo "📦 Installing Node.js dependencies..."
npm install --legacy-peer-deps

# Set up environment
echo "🔧 Setting up environment..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Environment file created from template"
fi

# Create data directory
mkdir -p data

# Generate Prisma client and run migrations
echo "🗄️ Setting up database..."
npx prisma generate
DATABASE_URL="file:$(pwd)/data/app.db" npx prisma migrate dev --name init

# Seed database
echo "🌱 Seeding database..."
DATABASE_URL="file:$(pwd)/data/app.db" npm run seed

echo ""
echo "🎉 Synthia Light setup complete!"
echo ""
echo "To start the server:"
echo "  cd synthia-light"
echo "  npm run dev"
echo ""
echo "Server will be available at http://localhost:3000"
echo "API documentation at http://localhost:3000/docs"
echo "Journal interface at http://localhost:3000/journal.html"