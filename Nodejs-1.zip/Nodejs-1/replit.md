# Synthia Light

## Overview

Synthia Light is a mobile-first web application that combines astrology, self-cultivation gaming, and creative world-building tools. The project serves as a headless backend for astrological charts, resonance mapping, and interactive games with a focus on mobile accessibility and responsive design.

The application features a compact journal interface with lazy-loaded JupyterLite integration, a Kaboom.js-based game engine for creating interactive worlds and sprites, and a comprehensive API for managing astrological data and game compilation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Fastify web server with TypeScript for type safety and modern JavaScript features
- **Database**: Prisma ORM for database abstraction and migrations
- **Logging**: Pino logger with pretty printing for development
- **Validation**: Zod for runtime type validation and API request/response schemas
- **CORS**: Cross-origin resource sharing enabled for frontend integration

### Frontend Architecture
- **Mobile-First Design**: Responsive CSS with max-width constraints and flexible layouts
- **Game Engine**: Kaboom.js for 2D game development and sprite manipulation
- **Build System**: Vite for fast development and optimized production builds
- **Lazy Loading**: JupyterLite notebooks load on-demand to improve initial page performance

### API Design
- **RESTful Endpoints**: Health checks, game compilation, and journal management
- **OpenAPI Documentation**: Swagger UI integration for API exploration
- **Game Compilation**: Rich specification system that generates complete Kaboom + Vite projects

### Data Architecture
- **Game Specifications**: JSON-based world definitions including scenes, tiles, sprites, and input mappings
- **Astrological Calculations**: Astronomia library for accurate celestial calculations
- **Unique Identifiers**: NanoID for generating short, URL-safe unique identifiers

### Development Workflow
- **Hot Reloading**: TSX watch mode for rapid development iteration
- **Testing**: Vitest for unit and integration testing
- **Build Process**: TypeScript compilation with source maps for debugging
- **CLI Tools**: Custom command-line interface for seeding and maintenance tasks

## External Dependencies

### Core Runtime Dependencies
- **Fastify**: High-performance web framework with plugin ecosystem
- **Prisma**: Database toolkit and ORM for TypeScript
- **Kaboom.js**: Game development library for 2D interactive experiences
- **Astronomia**: Astronomical calculations and ephemeris data
- **Zod**: TypeScript-first schema validation library

### Development Tools
- **TypeScript**: Static type checking and modern JavaScript features
- **Vite**: Fast build tool and development server
- **Vitest**: Testing framework optimized for Vite projects
- **TSX**: TypeScript execution environment for Node.js

### Third-Party Integrations
- **JupyterLite**: Browser-based Jupyter notebook environment (CDN-loaded)
- **OpenAPI/Swagger**: API documentation and testing interface
- **Pino**: Structured logging with multiple output formats

### Static Assets
- **Sprite Graphics**: Placeholder images for game development (cynthia.png, grass.png, rock.png)
- **Responsive CSS**: Mobile-optimized styling with collapsible panels
- **Game Templates**: Reusable Kaboom.js project structures for rapid prototyping