# Synthia Light Mobile

Mobile-first world/sprite maker with Kaboom.js games and JupyterLite journal.

## Quickstart

```bash
npm install && npm run dev
```

## Demo

```bash
npm run demo:game
```

Then open `/play` in your browser.

## Features

- **Mobile-first**: Responsive design, 720px max-width
- **Journal**: Lazy-loading JupyterLite integration
- **Game Maker**: JSON specs → Kaboom.js + Vite projects
- **World Builder**: Tiles, sprites, entities, inputs
- **One-click Deploy**: Games served at `/play`

## API

- `POST /mods/games-lite/compile` - Compile game from JSON spec
- `GET /healthz` - Health check
- `GET /readyz` - Readiness check
- `GET /docs` - OpenAPI documentation

## Game Spec Example

```json
{
  "spec": {
    "name": "My Game",
    "scenes": [{"name": "Play", "start": true}],
    "inputs": ["left", "right", "up", "space"],
    "world": {
      "tiles": [
        {"type": "ground", "sprite": "grass.png", "x": 0, "y": 120, "w": 400, "h": 24}
      ]
    },
    "entities": [
      {"name": "Player", "sprite": "cynthia.png", "x": 40, "y": 0, "components": ["pos", "area", "body", "jump"]}
    ]
  }
}
```

## Mobile Features

- Journal panel: 32vh (expandable to 70vh)
- Game canvas: Auto-scales to screen width
- Lazy JupyterLite: Loads only when requested
- Touch-friendly controls