#!/usr/bin/env bash
set -euo pipefail
curl -sX POST http://localhost:${PORT:-3000}/mods/games-lite/compile \
  -H 'Content-Type: application/json' \
  -d '{
    "spec": {
      "name":"Resonance Runner",
      "scenes":[{"name":"Play","start":true}],
      "inputs":["left","right","up","space"],
      "world": { "tiles": [
        { "type":"ground", "sprite":"grass.png", "x":0, "y":120, "w":400, "h":24 },
        { "type":"obstacle","sprite":"rock.png",  "x":160,"y":96,  "w":24,  "h":24 }
      ]},
      "entities":[{ "name":"Player","sprite":"cynthia.png","x":40,"y":0,"components":["pos","area","body","jump"] }]
    }
  }'
echo
echo "🎮 Open /play in your browser to play the game!"