#!/usr/bin/env node
// JSON spec -> Kaboom project -> vite build
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function readSpec() {
  let raw = null;
  const arg = process.argv[2];
  if (arg && fs.existsSync(arg)) raw = fs.readFileSync(arg, "utf8");
  else try { raw = fs.readFileSync(0, "utf8"); } catch {}
  if (!raw) die("Provide a spec JSON file or pipe JSON into STDIN.");
  let spec; try { spec = JSON.parse(raw); } catch(e){ die("Invalid JSON: "+e.message); }
  if (!spec.name) die("Spec must include { name }");
  spec.scenes = spec.scenes?.length ? spec.scenes : [{name:"Play", start:true}];
  spec.inputs = spec.inputs?.length ? spec.inputs : ["left","right","up","space"];
  spec.world = spec.world || { tiles: [] };
  spec.entities = spec.entities?.length ? spec.entities : [{ name:"Player", components:["pos","area","body","jump"], x:40, y:0 }];
  spec.goals = spec.goals || [];
  return spec;
}
function die(m){ console.error(m); process.exit(2); }
function ensureDir(p){ fs.mkdirSync(p, {recursive:true}); }
function write(p,c){ ensureDir(path.dirname(p)); fs.writeFileSync(p,c); }

const VITE_CFG = `import { defineConfig } from 'vite'
export default defineConfig({ server: { port: 5173 } })
`;

function kaboomMain(spec){
  const start = spec.scenes.find(s=>s.start)?.name || spec.scenes[0].name;
  const inputMap = {
    left: "onKeyDown('left', ()=> player.move(-SPEED,0))",
    right:"onKeyDown('right', ()=> player.move(SPEED,0))",
    up:   "onKeyPress('up', ()=> player.isGrounded() && player.jump())",
    space:"onKeyPress('space', ()=> player.isGrounded() && player.jump())",
    action:"// TODO: action"
  };
  const worldTiles = (spec.world.tiles||[]).map(t=>`
  // ${t.type||"tile"}
  add([
    ${(t.sprite?`sprite('${t.sprite.replace(/'/g,'')}')`:`rect(${t.w||24}, ${t.h||24})`)},
    pos(${t.x||0}, ${t.y||0}),
    area(),
    ${t.type==="ground"||t.type==="obstacle"?"solid(),":""}
  ])`).join("\n");

  const playerBlock = `
  const player = add([
    ${spec.entities[0]?.sprite?`sprite('${spec.entities[0].sprite.replace(/'/g,'')}')`:"rect(12,12)"},
    pos(${spec.entities[0]?.x||40}, ${spec.entities[0]?.y||0}),
    area(),
    body(),
    origin('center')
  ])`;

  const inputs = (spec.inputs||[]).map(k=>inputMap[k] || `// unmapped: ${k}`).join("\n  ");

  return `import kaboom from "kaboom"
kaboom({ background: [0,0,0], global: true })

const SPEED = 240

loadRoot("/assets/")
${(spec.world.tiles||[]).map(t=>t.sprite?`loadSprite("${t.sprite}", "${t.sprite}");`:"").join("\n")}
${spec.entities[0]?.sprite?`loadSprite("${spec.entities[0].sprite}", "${spec.entities[0].sprite}")`:""}

scene("Play", () => {
  layers(["game","ui"], "game")

  ${worldTiles}

  ${playerBlock}

  ${inputs}

  add([text("${spec.name}"), pos(8,8), layer("ui")])
})

go("${start}")
`;
}

(function main(){
  const spec = readSpec();
  const slug = spec.name.toLowerCase().replace(/[^a-z0-9]+/g,"-");
  const root = path.join(process.cwd(), "build", slug);
  ensureDir(root);

  // BASIC PROJECT
  const pkg = {
    name: slug, private:true, version:"0.1.0", type:"module",
    scripts: { dev:"vite", build:"vite build", preview:"vite preview" },
    devDependencies: { vite:"^5.0.0" },
    dependencies: { kaboom:"^3000.1.17" }
  };
  write(path.join(root,"package.json"), JSON.stringify(pkg,null,2));
  write(path.join(root,"vite.config.ts"), VITE_CFG);
  write(path.join(root,"index.html"), `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>${spec.name}</title><style>html,body,#app{height:100%;margin:0}canvas{width:100%;height:100%;object-fit:contain}</style></head><body><div id="app"></div><script type="module" src="/src/main.ts"></script></body></html>`);
  write(path.join(root,"src","main.ts"), kaboomMain(spec));

  // assets (copy placeholders from repo public/assets if available)
  const repoAssets = path.join(process.cwd(),"public","assets");
  ensureDir(path.join(root,"public","assets"));
  if (fs.existsSync(repoAssets)) {
    for (const f of fs.readdirSync(repoAssets)) {
      fs.copyFileSync(path.join(repoAssets,f), path.join(root,"public","assets",f));
    }
  }

  // build
  spawnSync("npm", ["install"], { cwd: root, stdio: "inherit" });
  spawnSync("npm", ["run","build"], { cwd: root, stdio: "inherit" });

  process.stdout.write(JSON.stringify({ ok:true, projectPath: root }));
})();