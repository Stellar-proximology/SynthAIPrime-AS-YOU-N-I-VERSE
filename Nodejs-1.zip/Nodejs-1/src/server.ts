// Express server with static pages, health, docs (optional), and games-lite compile
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import swaggerUi from "swagger-ui-express";
import YAML from "yamljs";
import gamesLite from "./routes/games-lite.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
app.use(express.json());

// STATIC
app.use(express.static(path.join(__dirname, "..", "public")));
app.get("/", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));
app.get("/journal", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "journal.html")));

// HEALTH
app.get("/healthz", (_req,res)=>res.json({status:"ok", timestamp: new Date().toISOString()}));
app.get("/readyz", (_req,res)=>res.json({ready:true, mods:["journal","games-lite"], timestamp:new Date().toISOString()}));

// JOURNAL STUB
app.get("/mods/journal/notebook", (req, res) => {
  const profile = req.query.profile || 'demo';
  res.json({
    cells: [
      {
        cell_type: "markdown",
        metadata: {},
        source: [`# Synthia Light Journal\nProfile: ${profile}\nDate: ${new Date().toISOString()}\n\nWelcome to your personal cultivation space.`]
      },
      {
        cell_type: "markdown", 
        metadata: {},
        source: ["## Today's Reflection\nWhat insights emerged for you today?"]
      },
      {
        cell_type: "code",
        execution_count: null,
        metadata: {},
        outputs: [],
        source: ['# Your reflection space\nreflection = ""\nprint(f"Today I learned: {reflection}")']
      }
    ],
    metadata: {
      kernelspec: {
        display_name: "Python 3",
        language: "python", 
        name: "python3"
      }
    },
    nbformat: 4,
    nbformat_minor: 4
  });
});

// DOCS (optional; only if openapi.yaml exists)
const openapiPath = path.join(__dirname,"..","openapi.yaml");
if (fs.existsSync(openapiPath)) {
  const spec = YAML.load(openapiPath);
  app.use("/docs", swaggerUi.serve, swaggerUi.setup(spec));
}

// GAMES LITE
app.use("/mods/games-lite", gamesLite(app));

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`[Synthia Light] listening on :${port}`);
});

export default app;