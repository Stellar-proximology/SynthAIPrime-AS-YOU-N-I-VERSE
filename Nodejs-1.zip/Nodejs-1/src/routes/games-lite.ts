import { Express, Request, Response } from "express";
import { spawn } from "child_process";
import path from "path";
import express from "express";

let lastPlayDir = "";

export default function gamesLite(app: Express) {
  const router = express.Router();
  
  router.post("/compile", async (req: Request, res: Response) => {
    const spec = req.body?.spec;
    if (!spec || !spec.name) return res.status(400).json({ ok:false, error:"Body must include { spec: { name } }" });

    const proc = spawn("node", ["scripts/game_maker.cjs"], { stdio: ["pipe","pipe","inherit"] });
    proc.stdin.write(JSON.stringify(spec));
    proc.stdin.end();

    let out = "";
    proc.stdout.on("data", d => out += d.toString());
    proc.on("close", (code) => {
      if (code !== 0) return res.status(500).json({ ok:false, error:"generator failed", code });

      try {
        const parsed = JSON.parse(out);
        lastPlayDir = parsed.projectPath;
        // mount /play to this project's dist after a build (game_maker runs vite build)
        app.use("/play", express.static(path.join(lastPlayDir, "dist")));
        return res.json({ ok:true, projectPath: parsed.projectPath, playPath: "/play" });
      } catch {
        return res.json({ ok:true, message:"generated", raw: out });
      }
    });
  });

  return router;
}